/********************************************************************
 ************ COPYRIGHT (c) 2023 by ke0ff, Taylor, TX   *************
 *
 *  File name: main.c
 *
 *  Module:    Control
 *
 *  Summary:   This is the IC-901 FAN PWM controller for the ATTiny-3217
 *
 *******************************************************************/

/********************************************************************
 *  File scope declarations revision history:
 *    08-27-22 jmh:  V9.x Forked original code source to incorp. IC901 PTT capture
 *    08-10-22 jmh:  V1.0 initial release.
 *    08-05-22 jmh:  by Joe Haas, KE0FF (creation date)
 *
 *******************************************************************/
/*
 * Created: 10/07/2023
 * Author : joe.haas
 * Executes the LMX2594 PLL controller.
 *
 * Uses USART, ADC, SPI, and Timer0A, and Timer0B
 *
 * ADC measures temperature (using a diode-connected PNP device)
 * Timer0A is input capture-freq meas to determine if Fan speed is correct
 * Timer0B is for application timers and 32b ETI
 * Timer1B is for fan-speed capture (frequency measure, 28 - 150 Hz)
 * SPI sends data to LMX part.
 * USART is for debug serial messages and configuration management
 * GPIO:	nPTT input controls output (on/off)
 *			GPIO drives freq channel selection
 *
 * System uses state machine logic to manage the PLL channel selection/update process:
 *		= PLL init process:
 *			1) Apply power to device.
 *			2) Program RESET = 1 to reset registers.
 *			3) Program RESET = 0 to remove reset.
 *			4) Program registers as shown in the register map in REVERSE order from highest to lowest.
 *			5) Wait 10 ms.
 *			6) Program register R0 one additional time with FCAL_EN = 1 to ensure that the VCO calibration
 *				runs from a stable state.
 *
 *		= PLL freq-change process:
 *			1) Change the N-divider value.
 *			2) Program the PLL numerator and denominator.
 *			3) Program FCAL_EN (R0[3]) = 1.
 *
 *		= The USART sends status messages at the state changes which include a display of the ETI.  The ETI
 *			is a continuous, 32b register which is used to approximately place events relative to the IPL
 *			time (ETI = 0).  Event messages such as PTT transitions and periodic temperature reporting
 *			are also sent via the USART interface.  Serial commands to monitor or control system are also
 *			available via the USART interface.  See process_UART() for details.
 *
 *		= GPIO transitions are used to switch freq channel
 *
 *		+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 *
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <atmel_start.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <driver_init.h>
#include <clock_config.h>
#include "main.h"
#include "serial.h"
#include "channels.h"

#define BB_SPI								// use bit-bang SPI

// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// conditional compile flags - none
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

#define SBAUD		115200L					// remote control baud rate

// process_xxx() command defines
#define IPL_CMD		0xff					// Initial Program Load (reset system variables)
#define NORM_CMD	0x00					// normal process

/////////////////////////////////////
// file local fn declares
uint8_t process_UART(uint8_t cmd);
void exec_cmd(char* sptr);
void init_ports(void);
void put_eti(void);
void put_vers(void);
void put_eti_msg(char* sp);
void init_spi(void);								// SPI, init GPIO, etc...
void send_spi24(uint32_t plldata);
void delay_halfbit(void);							// for BBSPI, this fnd is just used to set reg-reg xfr delay
void pll_ipl(void);

/////////////////////////////////////
// file local variables
static	uint16_t	temp0;							// current T0 temperature register (in integer degrees K)
//static	uint16_t	temp1;							// current T1 temperature register (in integer degrees K)
static	bool		alert;							// LED alert status
static	uint8_t		ptt_last;						// ptt holding reg
//static	uint16_t	fan_speed;					// fan speed holding reg


/////////////////////////////////////
// fn macros
//


////////////////////////////////////////////////////////////////////////////                                             
//			        ==     ==     =     =======  =     =        
//			        = =   = =    = =       =     ==    =        
//			        =  = =  =   =   =      =     = =   =        
//			        =   =   =  =     =     =     =  =  =        
//			        =       =  =======     =     =   = =        
//			        =       =  =     =     =     =    ==        
//			        =       =  =     =  =======  =     =        
////////////////////////////////////////////////////////////////////////////
// main()
int main(void){
	uint32_t	kk;					// temp 32
	uint16_t	alert_counter;		// 
	uint16_t	jj;					// temp, er, temp
	uint16_t	adc_last;			// last adc reading
	uint8_t		i;					// temp 8
	char		buf[30];			// sprintf temp buff

	atmel_start_init();										// init MCU
	init_ports();
	timer_ipl();
	init_spi();
	adc_last = 0;
	sei();													//enabling global interrupt
	// process initialization calls
	eti_read(ETI_IPL);										// IPL init of eti timer
	process_UART(IPL_CMD);									// init processes
	put_eti();
	alert = LED_NORM;
//	ALRT_set_level(alert);
	alert_counter = 20;
	chk_tmr4(alert_counter);
	ptt_last = 0xf0;
	//
	/* address change-capture application */
    while (1) // main loop (forever)
    {
		// alert LED/ETI msg. Alert LED flashes 5% on for normal operation, 95% on for ALERT indication
		if(!chk_tmr4(0)){									// I'm alive/Alert flash on alert LED
			if(alert_counter == 380){
				alert_counter = 20;
//				ALRT_set_level(!alert);						// the state of alert determines the LED duty cycle
				if(get_flag5()){							// send ETI msg @ 5 min intervals
					put_eti_msg(buf);
				}
			}else{
				alert_counter = 380;
//				ALRT_set_level(alert);
			}
			chk_tmr4(alert_counter);
		}
		i = nPTT_get_level();								// process PTT input & msgs
		if(i != ptt_last){
			if(!i){
				putss("Tone ON  ");
			}else{
				putss("Tone OFF ");				
			}
			put_eti();
			ptt_last = i;
		}
		// run each process function...
		process_UART(NORM_CMD);								// process UART commands
		// process temp
		jj = ADC_0_get();										// acquire temp sensor & convert to ENG units (degrees K)
		if(jj != adc_last){
			if(jj == 0x3ff){
				putss("TEMP error; ");							// send log msg
				put_eti();
				temp0 = 999;
				alert = 1;										// set alert
			}else{
				kk = (uint32_t)jj * 430L / 1023L;
				temp0 = (uint16_t)kk;
			}
			adc_last = jj;
		}

    } // end main while() loop
} // end main()
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////
// process_UART() handles the UART commands
//	serial I/O drivers are in serial.c/serial.h
//
uint8_t process_UART(uint8_t cmd){
//		uint8_t	i;				// temps
//		uint8_t	j;
//		uint8_t	k;
		char	cmd_buff[30];

	if(cmd == IPL_CMD){
		init_uart(SBAUD, ENABLE_RXD|ENABLE_TXD);			// enable RXD & TXD
		putss("\n============\n");
		put_vers();
		putss("Artemis Start...\n");
	}else{
		// process uart input:
		if(gotcr()){
			cmd_buff[0] = '\0';						// pre-clear cmd buffer
			getss(cmd_buff);						// get cmd line
			switch(cmd_buff[0]){
				case 'V':
					put_vers();						// display system version
				default:							// empty line displays eti msg
					put_eti_msg(cmd_buff);
					break;

				case 'p':							// "P" pll IPL config
				case 'P':
					pll_ipl();
					putss("<pll init>\n");
					break;

				case 's':							// "S" spi debug
				case 'S':
					send_spi24(0x00a5aa55);
//					sprintf(cmd_buff, "<set %d%%>\n", j);
//					putss(cmd_buff);
					putss("<spi dbg>\n");
					break;
			}  // end switch
		} // end if-gotcr
	} // end if-cmd
	return 0;
}


/////////////////////////////////////
// init_ports() initializes GPIO
//
void init_ports(void){

	// init GPIO
	PORTC.OUT = 0;
	PORTC.DIR = 0;
	PORTC.PIN0CTRL = PORT_PULLUPEN_bm;

	return;
}

/////////////////////////////////////
// put_eti() displays eti (in sec) on USART port
//
void put_eti(void){
	char	buf[32];

	putss("ETI: ");
	sprintf(buf,"%ld\n", eti_read(0));
	putss(buf);
	return;
}

/////////////////////////////////////
// put_eti() displays eti (in sec) on USART port
//
void put_eti_msg(char* sp){
	sprintf(sp, "T0:%d K; ", temp0);
	putss(sp);
	put_eti();
	return;
}

// *********************************************
//  ************* SPI SUBROUTINES *************
// *********************************************

/////////////////////////////////////
// init_spi() initializes SPI port, master
// PA1 = MOSI
// PA3 = SCK
//
void init_spi(void){								// for HWSPI, initialize MCU pins

	MOSI_set_level(0);								// MOSI
	SCK_set_level(0);								// SCK
	nCS_set_level(1);								// CS
	CE_set_level(0);								// chip enable
	return;	
}

/////////////////////////////////////
// pll_ipl() initializes the LMX2594
//

void pll_ipl(void){
	uint8_t		i;
	uint32_t*	pptr;

	send_spi24(R0_ADDR | R0_RESET);					// send reset
	send_spi24(R0_INIT);
	pptr = chan_ptr(0);
	// send static init array
	for(i=0; i < (uint8_t)chan_size(0); i++){
		send_spi24(*pptr++);
	}
	// pause
	wait_T(MS15);
	// enable VCO cal
	send_spi24(R0_INIT | R0_FCAL_EN);
	return;
}


//-----------------------------------------------------------------------------
// send_spi32
//-----------------------------------------------------------------------------
//
// sends 24 bit word to target via bit-bang SPI
//
void send_spi24(uint32_t plldata){
#ifdef BB_SPI
	uint32_t	mask;

	nCS_set_level(0);								// CS = low to clock in data
	for(mask = 0x00800000L; mask;){	// start shifting 24 bits starting at MSb
		if(mask & plldata) PORTA.OUT |= MOSI;		// set MOSI
		else PORTA.OUT &= ~MOSI;					// clear MOSI
		mask >>= 1;
//		delay_halfbit();							// delay half clock

//		SCK_set_level(1);
		PORTA.OUT |= SCK;							// clock = high
//		delay_halfbit();							// delay remaining half
//		SCK_set_level(0);
		PORTA.OUT &= ~SCK;							// clock low
	}
	delay_halfbit();								// delay for LE
	nCS_set_level(1);								// CS = hi to latch data
	delay_halfbit();								// pad intra-word xfers by a half bit
	return;	

#else
	uint8_t	i;	// loop temps
	uint8_t	d;
	union Data32 {	// temp union to parse out 32b word to 8b pieces
	   uint32_t l;
	   uint8_t b[4];
	} pllu;  

	pllu.l = plldata;
	nCS_set_level(0);								// CS = low to clock in data
	delay_halfbit();								// pad intra-word xfers by a half bit
	for(i=0; i < 4; i++){							// shifting 32 bits 8 bits at a time
		d = (uint8_t)(pllu.b[i]);
//		while(SPI0CFG & 0x80);						// wait for buffer to clear
//		SPI0DAT = d;
	}
//	while(SPI0CFG & 0x80);							// wait for buffer to clear
	delay_halfbit();								// pad intra-word xfers by a half bit
	nCS_set_level(1);								// CS = hi to latch data
	delay_halfbit();								// delay for RC pullup on revC CS line
	return;
#endif
}

//-----------------------------------------------------------------------------
// delay_halfbit
//-----------------------------------------------------------------------------
//
// sets delay for spi SCK and for CS setup/hold
//
	// BitBang version uses for-loop to establish ~~200 us delay
void delay_halfbit(void){
	volatile uint8_t	i;
	
	for(i = 0; i < 1;){							// cheezy for-next-loop to set delay for bit-bang-spi
													// 500 loops is approx 200us
		i += 1;
	}
	return;	
}
/*
#ifdef BB_SPI
	// BitBangSPI version uses HW timer0 to establish the bit-delay (200us, nominal)
	// T0 has about 0.5us of delay per timer tic when configured for clock source = SYSCLK/12
	// define 200us timer delay @24.5MHz/12 timer clock = (65536 - (400*0.5us))
#define	T0_VALUE	65136
#else
	// HWSPI version uses HW timer0 to establish quick delay (8us, nominal)
	// T0 has about 0.5us of delay per timer tic when configured for clock source = SYSCLK/12
	// define 8us timer delay @24.5MHz/12 timer clock = (65536 - (16*0.5us))
#define	T0_VALUE	0xFFF0
#endif

void delay_halfbit(void){							// for HWSPI, this fnd is just used to set reg-reg xfr delay

	TH0 = (T0_VALUE >> 8);							// prep timer registers for delay
	TL0 = (T0_VALUE & 0xFF);
	TF0 = 0;
	TR0 = 1;										// start timer
	while(TF0 == 0);								// loop
	TR0 = 0;										// stop timer
	return;	
}
*/

/////////////////////////////////////
// put_vers() displays system version
//
void put_vers(void){

	putss("Artemis 15GHz synth, V0.0, 10/07/23, de KE0FF\n");
	return;
}

// eof
