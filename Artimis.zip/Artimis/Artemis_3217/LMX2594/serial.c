/********************************************************************
 ************ COPYRIGHT (c) 2022 by ke0ff, Taylor, TX   *************
 *
 *  File name: serial.c
 *
 *  Module:    Control
 *
 *  Summary:   This is the serial I/O module for the banksw/RDU app
 *
 *******************************************************************/

/********************************************************************
 *  File scope declarations revision history:
 *    02-20-22 jmh:  creation date
 *
 *******************************************************************/

#include <driver_init.h>
#include <compiler.h>
#include <avr/io.h>
#include "serial.h"
#include "main.h"

//=================================
// local defines
//=================================

#define RXD_ERR 0x01
#define RXD_BS 0x04					// BS rcvd flag
#define RXD_ESC 0x40				// ESC rcvd flag
#define RXD_CHAR 0x80				// CHAR rcvd flag (not used)
#define RXD_BUFF_END 64

//=================================
// file-scope variable declarations
//=================================

char	rxd_buff[RXD_BUFF_END];		// rx data buffer
uint8_t	rxd_hptr;					// rx buf head ptr = next available buffer input
uint8_t	rxd_tptr;					// rx buf tail ptr = next available buffer output
uint8_t	rxd_stat;					// rx buff status
uint8_t	rxd_crcnt;					// CR counter

//=================================
// file-scope fn declarations
//=================================

char hex_asc(uint8_t c);

//=================================
// source code
//=================================

//-----------------------------------------------------------------------------
// init_uart() initializes serial port vars
//	allows separate enabling of RX and TX usinf "rx" and "tx" booleans
//-----------------------------------------------------------------------------
//
void init_uart(uint32_t baudr, uint8_t enab){
	rxd_hptr = 0;										// rx buf head ptr
	rxd_tptr = 0;										// rx buf tail ptr
	rxd_stat = 0;										// rx buff status
	rxd_crcnt = 0;										// init cr counter
	// init uart periph.
	USART0.BAUD = (uint16_t)USART0_BAUD_RATE(baudr);	// baud rate
	USART0.CTRLA |= USART_RXCIE_bm;						// control = RX ISR enabled
	USART0.CTRLC = USART_SBMODE_bm | 0x03;				//	2stop bits, 8 data bits
	if(enab & ENABLE_RXD){
		PORTB.DIR &= ~RXDp;
		USART0.CTRLB |= USART_RXEN_bm;					//	RX=enabled
	}
	if(enab & ENABLE_TXD){
		PORTB.OUT |= TXDp;								// init I/O pins
		PORTB.DIR |= TXDp;
		USART0.CTRLB |= USART_TXEN_bm;					//	TX=enabled
	}
	return;
}

//-----------------------------------------------------------------------------
// putch, UART0
//-----------------------------------------------------------------------------
//
// SFR Paged version of putch, no CRLF translation
//
char putch(char c){

	// output character
	while (!(USART0.STATUS & USART_DREIF_bm));
	USART0.TXDATAL = c;
	return c;
}

//-----------------------------------------------------------------------------
// getch00 checks for input @ RX0.  If no chr, return '\0'.
//-----------------------------------------------------------------------------
//
// SFR Paged, waits for a chr and returns
// Processor spends most of its idle time waiting in this fn
//
char getch00(void){
	char c = '\0';		// default to null return

	if(rxd_tptr != rxd_hptr){			// make sure buffer not empty
		c = rxd_buff[rxd_tptr++];		// get chr from buff
		if(rxd_tptr == RXD_BUFF_END){	// and update tail pointer
			rxd_tptr = 0;
		}
	}
	return c;
}

//-----------------------------------------------------------------------------
// cleanline() cleans buffer up to and including 1st CR.  
//	Pull CHRS from buffer and discard until first CR is encountered.  Then, exit.
//-----------------------------------------------------------------------------
//
void cleanline(void){
	char c;	// temp char

	if(rxd_tptr != rxd_hptr){							// skip if buffer empty
		do{
			c = rxd_buff[rxd_tptr++];					// pull chr and update pointer
			if(rxd_tptr == RXD_BUFF_END){
				rxd_tptr = 0;
			}
		}while((c != '\r') && (rxd_tptr != rxd_hptr));	// repeat until CR or buffer empty
	}
	return;
}

//-----------------------------------------------------------------------------
// gotch00 checks for input @ RX0.  If no chr, return '\0'.
//-----------------------------------------------------------------------------
//
// returns 0 if no chr in buffer or if current chr is '\r'
//
char gotch00(void){
	char c = 0;

	if((rxd_tptr != rxd_hptr) && (rxd_buff[rxd_tptr] != '\r')){
		c = 1;								// set buffer has data
	}
	if(rxd_stat & RXD_BS){					// process backspace
		rxd_stat &= ~RXD_BS;				// clear flag
		putss("\b \b");						// echo clearing BS to terminal
	}
	return c;
}

//-----------------------------------------------------------------------------
// gotcr checks for '\r' @ RX0.  If no chr, return '\0'.
//-----------------------------------------------------------------------------
//
// returns 0 if no cr rcvd
//
char gotcr(void){
	char c = 0;

	if(rxd_crcnt){
		rxd_crcnt--;						// clear flag
		c = 1;								// set buffer has data
	}
	return c;
}

//-----------------------------------------------------------------------------
// putss() does puts w/o newline
//-----------------------------------------------------------------------------
//
void putss (char* string){
	while(*string){
		if(*string == '\n') putch('\r');
		putch(*string++);
	}
	return;
}

//-----------------------------------------------------------------------------
// put_byte(p) gets converts U8 to 2-byte ascii hex and sends to serial port
//-----------------------------------------------------------------------------
char* puts_byte(char* s, uint8_t d){
	
	*s++ = (hex_asc(d >> 4));
	*s++ = (hex_asc(d));
	return s;
}

//-----------------------------------------------------------------------------
// hex_asc(p) converts binary nybble to ascii hex and returns
//-----------------------------------------------------------------------------
char hex_asc(uint8_t c){

	char b;

	b = (char)(c & 0x0f) + '0';			// add '0' to convert decimal nyb to ascii
	if(b > '9') b += 'A' - '9' - 1;		// if hex, add ("A' - '9' - 1) to get ascii
	return b;
}

//-----------------------------------------------------------------------------
// getss() copies input line to pointer dest, returns end of dest
//-----------------------------------------------------------------------------
//
char* getss (char* dest){
	char	c;					// temp char
//	uint8_t	err = 0;			// err flag (breaks while loop if error)
	char*	sp = dest;

	do{
		c = getch00();
		*sp++ = c;
	}while(c);
	*sp = '\0';									// null term dest
	if(rxd_crcnt){
		cli();									// no interrupts for this calculation..
		rxd_crcnt--;							// decrement line counter
		sei();
	}
	return sp;
}

//=================================
// ISR source code
//=================================

//-----------------------------------------------------------------------------
// USART0 rx intr.  Captures RX data and places into circular buffer
//
ISR(USART0_RXC_vect){
	char	c;

	c = USART0.RXDATAL;
	if((c > ESC) || (c == EOL)){
		if(c == EOL){
			c = '\0';								// null-term lines
		}
		rxd_buff[rxd_hptr++] = c;							// feed the buffer
		if(rxd_hptr >= RXD_BUFF_END){
			rxd_hptr = 0;									// wrap buffer ptr
		}
		if(rxd_hptr == rxd_tptr){
			rxd_stat |= RXD_ERR;							// buffer overrun, set error
		}
		if(c == '\0') rxd_crcnt++;							// increment msg count if EOM (now a null in the datastream) is detected
	}
}

// eof