/********************************************************************
 ************ COPYRIGHT (c) 2023 by ke0ff, Taylor, TX   *************
 *
 *  File name: main.c
 *
 *  Module:    Control
 *
 *  Summary:   This is the Artimis PLL Synthesizer controller for the ATTiny-3217
 *
 *******************************************************************/

/********************************************************************
 *  File scope declarations revision history:
 *    10-01-23 jmh:  by Joe Haas, KE0FF (creation date)
 *
 *******************************************************************/
/*
 * Created: 10/07/2023
 * Author : joe.haas
 * Executes the LMX2594 PLL controller.
 *
 * V0.2 Revnotes	10/16/24
 *	Cal'd temp sensor TLO value to match cold-on readings (external)
 *	channel register storage now only captures low 16b of each reg to save RAM/FLASH space.
 *		reg# is added at run-time by the send-data loop
 *	4-channels now supported
 *	re-vamped UART commands and added help ? cmd
 *  System now reports all FSEL input changes, but masks the active channel with FSEL_M.
 *		This mostly is in support of the ATP.
 *
 * V0.1 Revnotes	02/01/24 (circa)
 *	Initial release (debug) 1CH test loop
 *
 * Uses USART, ADC, SPI, and Timer0A, and Timer0B
 *
 * ADC measures temperature (using a diode-connected PNP device)
 * Timer0A is input capture-freq meas to determine if Fan speed is correct
 * Timer0B is for application timers and 32b ETI
 * Timer1B is for fan-speed capture (frequency measure, 28 - 150 Hz)
 * SPI sends data to LMX part.
 * USART is for debug serial messages and configuration management
 * GPIO:	nPTT input controls output (on/off)
 *			GPIO drives freq channel selection
 *
 * System uses state machine logic to manage the PLL channel selection/update process:
 *		= PLL init process:
 *			1) Apply power to device.
 *			2) Program RESET = 1 to reset registers.
 *			3) Program RESET = 0 to remove reset.
 *			4) Program registers as shown in the register map in REVERSE order from highest to lowest.
 *			5) Wait 10 ms.
 *			6) Program register R0 one additional time with FCAL_EN = 1 to ensure that the VCO calibration
 *				runs from a stable state.
 *
 *		= PLL freq-change process:
 *			1) Change the N-divider value.
 *			2) Program the PLL numerator and denominator.
 *			3) Program FCAL_EN (R0[3]) = 1.
 *
 *		= The USART sends status messages at the state changes which include a display of the ETI.  The ETI
 *			is a continuous, 32b register which is used to approximately place events relative to the IPL
 *			time (ETI = 0).  Event messages such as PTT transitions and periodic temperature reporting
 *			are also sent via the USART interface.  Serial commands to monitor or control system functions
 *			are also available via the USART interface.  See process_UART() for details.
 *
 *		= GPIO transitions are used to switch freq channel
 *
 *		+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 *
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <atmel_start.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <driver_init.h>
#include <clock_config.h>
#include "main.h"
#include "serial.h"
#include "channels.h"

#define BB_SPI								// use bit-bang SPI

// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// conditional compile flags - none
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

#define SBAUD		9600L //115200L					// remote control baud rate

// process_xxx() command defines
#define IPL_CMD		0xff					// Initial Program Load (reset system variables)
#define NORM_CMD	0x00					// normal process

/////////////////////////////////////
// file local fn declares
uint8_t process_UART(uint8_t cmd);
void exec_cmd(char* sptr);
void init_ports(void);
void put_eti(void);
void put_vers(void);
void put_eti_msg(char* sp);
void init_spi(void);								// SPI, init GPIO, etc...
void send_spi24(uint32_t plldata);
void delay_halfbit(void);							// for BBSPI, this fnd is just used to set reg-reg xfr delay
void pll_ipl(uint8_t chan);

/////////////////////////////////////
// file local variables
#define TMPMAX	8
static	uint16_t	temp0[TMPMAX];					// current T0 temperature array (in integer degrees K)
static	uint16_t	temp1[TMPMAX];					// current T1 temperature array (in integer degrees K)
static	uint8_t		tmptr;							// current temp reg
static	bool		alert;							// LED alert status
static	bool		ipl;							// ipl flag
static	uint8_t		ptt_last;						// ptt holding reg
//static	uint16_t	fan_speed;					// fan speed holding reg


/////////////////////////////////////
// fn macros
//


////////////////////////////////////////////////////////////////////////////                                             
//			        ==     ==     =     =======  =     =        
//			        = =   = =    = =       =     ==    =        
//			        =  = =  =   =   =      =     = =   =        
//			        =   =   =  =     =     =     =  =  =        
//			        =       =  =======     =     =   = =        
//			        =       =  =     =     =     =    ==        
//			        =       =  =     =  =======  =     =        
////////////////////////////////////////////////////////////////////////////
// main()
int main(void){
	int32_t				kk;					// temp 32
	uint16_t			alert_counter;		// 
	uint16_t			jj;					// temp, er, temp
	uint16_t			adc_last;			// last adc reading
	uint8_t				i;					// temp 8
	uint8_t				j;					// temp 8
	uint8_t				fsel_edge;			// fsel edge holding reg
	char				buf[30];			// sprintf temp buff
	static	uint16_t*	ctptr;				// current temp ptr

	atmel_start_init();										// init MCU
	init_ports();
	// countermand init...
/*	MUXO_set_dir(PORT_DIR_OUT);

	MUXO_set_pull_mode(
	    // <y> Pull configuration
	    // <id> pad_pull_config
	    PORT_PULL_OFF // Off
	    // <PORT_PULL_UP"> Pull-up
	    // PORT_PULL_UP
		);
		MUXO_set_level(1);*/

	timer_ipl();
	init_spi();
	adc_last = 0;
	tmptr = 0;
	ctptr = temp0;
	ipl = 1;
	sei();													//enabling global interrupt
	// process initialization calls
	eti_read(ETI_IPL);										// IPL init of eti timer
	process_UART(IPL_CMD);									// init processes
	put_eti();
	fsel_edge = 0xff;										// force update of ch/ptt
	alert = LED_NORM;
//	ALRT_set_level(alert);
	alert_counter = 20;
	chk_tmr4(alert_counter);
	ptt_last = 0xf0;
	CE_set_level(1);
//	pll_ipl();
	putss("<pll start>\n");

	//
	/* address change-capture application */
    while (1) // main loop (forever)
    {
		// alert LED/ETI msg. Alert LED flashes 5% on for normal operation, 95% on for ALERT indication
		if(!chk_tmr4(0)){									// I'm alive/Alert flash on alert LED
			// process alert
			if(alert_counter == 380){
				alert_counter = 20;
//				ALRT_set_level(!alert);						// the state of alert determines the LED duty cycle
//				MUXO_set_level(1);
				if(get_flag5()){							// send ETI msg @ 5 min intervals
					put_eti_msg(buf);
				}
			}else{
				alert_counter = 380;
//				ALRT_set_level(alert);
//				MUXO_set_level(0);
			}
			chk_tmr4(alert_counter);
		}
		i = nPTT_get_level();								// process PTT input & msgs
		if(i != ptt_last){
			if(i){
				CE_set_level(1);
				putss("Tone ON  ");
			}else{
				CE_set_level(0);
				putss("Tone OFF ");				
			}
			put_eti();
			ptt_last = i;
			wait_T(MS15);
		}
		i = PORTC_get_port_level() & (FSEL_MSK);
		if(i != fsel_edge){
			fsel_edge = i;
			j = ~fsel_edge & FSEL_MSK;
			pll_ipl(j & FSEL_M);							// nPTT = GND = enable PLL (plus 15ms debounce delay)
			sprintf(buf, "CH set: %d", j);
			putss(buf);
			sprintf(buf, "  PLL set: %d\n", j&FSEL_M);
			putss(buf);
		}
		// run each process function...
		process_UART(NORM_CMD);								// process UART commands
		// process temp
		

		if(ADC_0_got()){
			jj = ADC_0_get();										// acquire temp sensor & convert to ENG units (degrees K)
			if(jj != adc_last){
				if(jj == 0x3ff){
					putss("TEMP error; ");							// send log msg
					put_eti();
					ctptr[tmptr] = 999;
					if(++tmptr >= TMPMAX) tmptr = 0;
					alert = 1;										// set alert
				}else{
					kk = ((int32_t)jj - ADCLO) * (-1L*KADC);		// T = To + ((ADC - ADCLO)*KADC)
					kk /= 1000L;
					ctptr[tmptr] = (uint16_t)(kk+TLO);
					if(ipl){
						temp1[0] = 2900;
						for(i=1; i<TMPMAX; i++){
							temp0[i] = temp0[0];
							temp1[i] = temp1[0];
						}
						ipl = 0;
					}
					if(++tmptr >= TMPMAX){
						tmptr = 0;
						if(ctptr == temp0){
							ADC0.MUXPOS = ADC_MUXPOS_AIN5_gc; /* ADC input pin 1 */
							ctptr = temp1;
						}else{
							ADC0.MUXPOS = ADC_MUXPOS_AIN4_gc; /* ADC input pin 0 */
							ctptr = temp0;
						}
					}
				}
				adc_last = jj;
			}
		}

    } // end main while() loop
} // end main()
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////
// process_UART() handles the UART commands
//	serial I/O drivers are in serial.c/serial.h
//
uint8_t process_UART(uint8_t cmd){
//		uint8_t	i;				// temps
//		uint8_t	j;
//		uint8_t	k;
		char	cmd_buff[30];
		char	obuf[5];
		volatile char	c;

	if(cmd == IPL_CMD){
		init_uart(SBAUD, ENABLE_RXD|ENABLE_TXD);			// enable RXD & TXD
		putss("\n============\n");
		put_vers();
		putss("Artemis Start...\n");
	}else{
		// process uart input:
		if(gotcr()){
			cmd_buff[0] = '\0';						// pre-clear cmd buffer
			getss(cmd_buff);						// get cmd line
			c = cmd_buff[0];
			switch(c){
				case 'V':
					put_vers();						// display system version
				default:							// empty line displays eti msg
					put_eti_msg(cmd_buff);
					break;

/*				case 'p':							// "P" pll IPL config
				case 'P':
					pll_ipl(0);
					putss("<pll init>\n");
					break;*/

				case '0':							// CH0
				case '1':							// CH1
				case '2':							// CH2
				case '3':							// CH3
					pll_ipl(c-'0');
					putss("Set CH: ");
					obuf[0] = c;
					obuf[1] = '\n';
					obuf[3] = '\0';
					putss(obuf);
					break;
					
				case 'n':							// "N" init pll GPIO
				case 'N':
					CE_set_level(1);
					putss("<pll ON>\n");
				break;
					
				case 'f':							// "F" pll chip off
				case 'F':
					CE_set_level(0);
					putss("<pll OFF>\n");
					break;
					
				case '?':							// help
					putss("\nArtemis Help:\n");
					putss("0-3: set PLL CH\n");
					putss("n: tone on\n");
					putss("f: tone off\n");
					putss("<ENTER>: display ETI(sec)/temp(K) stats\n");
					putss("    T0=regulator, T1=PLL\n");
					putss("V: SW Version\n\n");
					break;

/*				case 's':							// "S" spi debug
				case 'S':
					send_spi24(0x00a5aa55);
//					sprintf(cmd_buff, "<set %d%%>\n", j);
//					putss(cmd_buff);
					putss("<spi dbg>\n");
					break;*/
			}  // end switch
		} // end if-gotcr
	} // end if-cmd
	return 0;
}


/////////////////////////////////////
// init_ports() initializes GPIO
//
void init_ports(void){

	// init GPIO
	PORTC.OUT = 0;
	PORTC.DIR = 0;
	PORTC.PIN0CTRL = PORT_PULLUPEN_bm;

	return;
}

/////////////////////////////////////
// put_eti() displays eti (in sec) on USART port
//
void put_eti(void){
	char	buf[32];

	putss("ETI: ");
	sprintf(buf,"%ld\n", eti_read(0));
	putss(buf);
	return;
}

/////////////////////////////////////
// put_eti() displays eti (in sec) on USART port
//
void put_eti_msg(char* sp){
	uint32_t	jj = 0;
	uint32_t	kk = 0;
	uint8_t		i;

	for(i=0; i<TMPMAX; i++){
		jj += (uint32_t)temp0[i];
		kk += (uint32_t)temp1[i];
	}
	jj /= TMPMAX;
	kk /= TMPMAX;
	sprintf(sp, "T0:%d.%d K; ", (int)jj/10, (int)jj%10);
	putss(sp);
	sprintf(sp, "T1:%d.%d K; ", (int)kk/10, (int)kk%10);
	putss(sp);
	put_eti();
	return;
}

// *********************************************
//  ************* SPI SUBROUTINES *************
// *********************************************

/////////////////////////////////////
// init_spi() initializes SPI port, master
// PA1 = MOSI
// PA3 = SCK
//
void init_spi(void){								// for HWSPI, initialize MCU pins

	MOSI_set_level(0);								// MOSI
	SCK_set_level(0);								// SCK
	nCS_set_level(1);								// CS
	CE_set_level(0);								// chip enable
	return;	
}

/////////////////////////////////////
// pll_ipl() initializes the LMX2594 to the given channel#
//
void pll_ipl(uint8_t chan){
	volatile uint32_t	i;
	volatile uint16_t*	pptr;
	volatile uint32_t	ss;		// spi data

	send_spi24(R0_ADDR | R0_RESET);					// send reset
	send_spi24(R0_INIT);
	pptr = chan_ptr(chan);							// get pointer to channel data
	if(pptr == NULL){
			putss("CHAN ERR\n");					// pointer error
	}else{
		// send chan array with reg addr (bits [23:16])
		for(i=REGNUM_START; i <= REGNUM_START; i-=0x10000L){
			ss = i | (uint32_t)(*pptr++);			// add register addr
			send_spi24(ss);
		}
	}
	// pause (for debounce)
	wait_T(MS15);
	// enable VCO cal
	send_spi24(R0_INIT | R0_FCAL_EN);
	send_spi24(R0_INIT);
	return;
}


//-----------------------------------------------------------------------------
// send_spi32
//-----------------------------------------------------------------------------
//
// sends 24 bit word to target via bit-bang SPI
//
void send_spi24(uint32_t plldata){
#ifdef BB_SPI
	uint32_t	mask;

	nCS_set_level(0);								// CS = low to clock in data
	for(mask = 0x00800000L; mask;){	// start shifting 24 bits starting at MSb
		if(mask & plldata) PORTA.OUT |= MOSI;		// set MOSI
		else PORTA.OUT &= ~MOSI;					// clear MOSI
		mask >>= 1;
//		delay_halfbit();							// delay half clock

//		SCK_set_level(1);
		PORTA.OUT |= SCK;							// clock = high
//		delay_halfbit();							// delay remaining half
//		SCK_set_level(0);
		PORTA.OUT &= ~SCK;							// clock low
	}
	delay_halfbit();								// delay for LE
	nCS_set_level(1);								// CS = hi to latch data
	delay_halfbit();								// pad intra-word xfers by a half bit
	return;	

#else
	uint8_t	i;	// loop temps
	uint8_t	d;
	union Data32 {	// temp union to parse out 32b word to 8b pieces
	   uint32_t l;
	   uint8_t b[4];
	} pllu;  

	pllu.l = plldata;
	nCS_set_level(0);								// CS = low to clock in data
	delay_halfbit();								// pad intra-word xfers by a half bit
	for(i=0; i < 4; i++){							// shifting 32 bits 8 bits at a time
		d = (uint8_t)(pllu.b[i]);
//		while(SPI0CFG & 0x80);						// wait for buffer to clear
//		SPI0DAT = d;
	}
//	while(SPI0CFG & 0x80);							// wait for buffer to clear
	delay_halfbit();								// pad intra-word xfers by a half bit
	nCS_set_level(1);								// CS = hi to latch data
	delay_halfbit();								// delay for RC pullup on revC CS line
	return;
#endif
}

//-----------------------------------------------------------------------------
// delay_halfbit
//-----------------------------------------------------------------------------
//
// sets delay for spi SCK and for CS setup/hold
//
	// BitBang version uses for-loop to establish ~~200 us delay
void delay_halfbit(void){
	volatile uint8_t	i;
	
	for(i = 0; i < 1;){							// cheezy for-next-loop to set delay for bit-bang-spi
													// 500 loops is approx 200us
		i += 1;
	}
	return;	
}
/*
#ifdef BB_SPI
	// BitBangSPI version uses HW timer0 to establish the bit-delay (200us, nominal)
	// T0 has about 0.5us of delay per timer tic when configured for clock source = SYSCLK/12
	// define 200us timer delay @24.5MHz/12 timer clock = (65536 - (400*0.5us))
#define	T0_VALUE	65136
#else
	// HWSPI version uses HW timer0 to establish quick delay (8us, nominal)
	// T0 has about 0.5us of delay per timer tic when configured for clock source = SYSCLK/12
	// define 8us timer delay @24.5MHz/12 timer clock = (65536 - (16*0.5us))
#define	T0_VALUE	0xFFF0
#endif

void delay_halfbit(void){							// for HWSPI, this fnd is just used to set reg-reg xfr delay

	TH0 = (T0_VALUE >> 8);							// prep timer registers for delay
	TL0 = (T0_VALUE & 0xFF);
	TF0 = 0;
	TR0 = 1;										// start timer
	while(TF0 == 0);								// loop
	TR0 = 0;										// stop timer
	return;	
}
*/

/////////////////////////////////////
// put_vers() displays system version
//
void put_vers(void){

	putss("Artemis 2-15GHz PLL, V0.2, 4-chan\n");
	putss("'?<ent>' for help, 09/24/24, de KE0FF\n");
	return;
}

// eof
