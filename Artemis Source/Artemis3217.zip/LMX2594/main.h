/********************************************************************
 ************ COPYRIGHT (c) 2022 by ke0ff, Taylor, TX   *************
 *
 *  File name: main.h
 *
 *  Module:    Control
 *
 *  Summary:   This is the header file for the banksw/rdu app.
 *
 *******************************************************************/


/********************************************************************
 *  File scope declarations revision history:
 *    02-20-22 jmh:  creation date
 *
 *******************************************************************/
#include "mcu.h"
#include <clock_config.h>

//------------------------------------------------------------------------------
// extern defines
//------------------------------------------------------------------------------

// DIODE temp sensor defines, 3906
//#define KADC	47L							// Kadc * 100
//#define ADCLO	801							// ADC low extrapolated to -55C
//#define TLO		21800						// -55C * 100
// 4.7K bias PNP
#define KADC	3735L						// Kadc * 10000
#define ADCLO	1070						// ADC low extrapolated to -55C
#define TLO		2040						// -55C * 10 -- was 2180

// Timer defines

#define MS_PER_TIC			5L
#define T1B_5MS				(F_CPU * MS_PER_TIC / 1000)			// 0x411a = 16666 = 5ms @ 20 MHz sysclk
// timer value defines -- This timer lashup has an uncertainty of +1,-0 base-units due to the uncertainty of synchronization with the prescaler in the MCU hardware.
//		Thus, for low timer values (values less than, say, 5) add a unit to cover this.
//#define MS5			(380*2)				// 5ms			// cheesy for-loop timing value 378 was measured and verified in the TUNE build using 20MHz master clock and 3.333MHz processor clock //
#define TIC			MS_PER_TIC				// #ms per ISR "tic"
#define MS5			((5/TIC) + 1)			// 5ms, plus 1 for the ISR alignment uncertainty
#define MS10		(10/TIC)				// 10ms
#define MS15		(15/TIC)				// 15ms
#define MS20		(20/TIC)				// 20ms
#define MS35		(35/TIC)				// 35ms
#define MS45		(45/TIC)				// 45ms
#define MS75		(75/TIC)				// 75ms
#define MS100		(100/TIC)				// 100ms
#define MS200		(200/TIC)				// 200ms
#define MS300		(300/TIC)				// 300ms
#define MS450		(450/TIC)				// 450ms
#define MS1000		(1000L/TIC)				// 1s
#define RAMP_RATE	MS200					// fan ramp rate delay

#define FAN_INIT_DLY	MS1000
#define FIVE_MINS		(5L * 60L * MS1000)
#define ETI_IPL			0x5a
#define TIMER_CLEAR		0xffff				// timer clear cmd

// single-slope PWM/TimerA defines
#define MIN_TMRFREQ			1000				// minimum valid count value from TimerB freq measurement

#define LED_NORM			0
#define LED_ALERT			1

// PA0 = UPDI
#define MOSI		0x02				// PA1  PLL_MOSI
#define MISO		0x04				// PA2	PLL_MISO
#define SCK			0x08				// PA3	PLL_SCK
#define TSENS0		0x10				// PA4	TS0_P
#define TSENS1		0x20				// PA5	TS1_P
#define MUXO		0x40				// PA6	PLL_MUXO
#define CE			0x80				// PA7	PLL_CE

#define RSCK		0x01				// PB0	PLL_RSCK
#define SYNC		0x02				// PB1	PLL_SYNC
#define TXDp		0x04				// PB2 = TXD (TRG>>HST)
#define RXDp		0x08				// PB3 = RXD (HST>>TRG)
#define SYSRFREQ	0x10				// PB4	PLL_SYSRFREQ
#define CS			0x20				// PB5	PLL_CS
#define TS_BIAS		0x40				// PB6	temp sense bias

#define FSEL0		0x01				// PC0	FSEL0
#define FSEL1		0x02				// PC1	FSEL1
#define FSEL2		0x04				// PC2	FSEL2
#define FSEL3		0x08				// PC3	FSEL3
#define FSEL4		0x10				// PC4	FSEL4
#define nPTT		0x20				// PC5	nPTT
#define FSEL_M		(FSEL0|FSEL1)
#define FSEL_MSK	(FSEL0|FSEL1|FSEL2|FSEL3|FSEL4)

////////////////////////////////////////////////////////////////
//
// PLL Register bit-map

#define PLL_READ	(uint32_t)(0x00800000L)	// READ bit for SPI transfers

#define R0_ADDR		(uint32_t)(0L << 16)
#define R0_INIT		0x00241C

#define R0_RESET	0x0002				// PLL reset
#define	R0_FCAL_EN	0x0008				// PLL VCO cal en/reset
#define R0_MUXO_LDSEL 0x0004			// PLL MUXO??
#define R0_OUT_MUTE	0x0200				// PLL RF mute
#define R0_PWR_DN	0x0001				// PLL chip power down


// end main.h