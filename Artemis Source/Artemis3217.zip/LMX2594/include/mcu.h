///////////////////////////////////////////////
//
// define the project MCU variant
//
///////////////////////////////////////////////
//#include "main.h"

#ifndef CPUMHZ
#define CPUMHZ 20				// This define sets CPU clock freq (20 or 16 MHz) it must be manually
								// set to differentiate the automotive parts (16 MHz) used on the
								// CuriosityNano from the "normal" parts (20 MHz) used on most of my projects
#endif

// eof
