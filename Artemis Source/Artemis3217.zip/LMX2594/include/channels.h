/**
 * \file
 *
 * \brief header file
 *
 *
 */

#ifndef CHANNELS_H_INCLUDED
#define CHANNELS_H_INCLUDED

#include <compiler.h>

#ifdef __cplusplus
extern "C" {
#endif

#define REGNUM_START		0x4F0000L		// REG addr of first register in channel array

uint16_t* chan_ptr(uint8_t chan);
uint16_t chan_size(uint8_t chan);

#ifdef __cplusplus
}
#endif

#endif /* CHANNELS_H_INCLUDED */
