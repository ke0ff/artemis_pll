/********************************************************************
 ************ COPYRIGHT (c) 2025 by ke0ff, Taylor, TX   *************
 *
 *  File name: main.c
 *
 *  Module:    Control
 *
 *  Summary:   This is the Artemis PLL Synthesizer controller for the ATTiny-3217
 *
 *******************************************************************/

/********************************************************************
 *  File scope declarations revision history:
 *    10-01-23 jmh:  by Joe Haas, KE0FF (creation date)
 *
 *******************************************************************/
/*
 * Created: 10/07/2023
 * Author : joe.haas
 * Executes the LMX2594 PLL controller.
 *
 * V0.3 Revnotes	03/28/25
 *	Reworked c/C/o/O syntax, removing space between cmd and sensor#.  Also removed space from
 *		"P" cmd.
 *	Added "t" cmd to send sram chan to pll.  Modified PLL send Fn to trap chan == 0xff to diff
 *		between FLASH (0-7) and SRAM (0xff) channels.
 *	Added cal aid to read raw adc values.
 *	Added ipll flag to trap IPL with tone off.  Inhibits PLL update until first tone on event.
 *	Modified ADC and cal/offs system.  Now, raw ADC values are buffered and each channel has its
 *		own cal/offs value.  c/C/o/O cal utils now have "1/0" param to indicate the channel.
 *	Tested temp cal/offs.
 *
 *	Fixed bug in CLI channel override.  Was skipping index[2] leaving an uninitialized character
 *		in the serial buffer.
 *	Added "size == 0" trap in step 2 of FLASH block write to trap the case where the end of data
 *		coincides with the end of FLASH page.  Prevents un-needed re-write of next page or error
 *		if the last page of FLASH (wraps out of FLASH area).
 *	FLASH erase/write is now working.  Must set BOOTEND to end of code FLASH ($76 in this case).
 *		APPEND is don't care (leave it at $00).  This mucks up the vector table, which means
 *		that one must either somehow(???) move the table in the linker, or set IVSEL before
 *		interrupts are enabled (very near the top of main() ):
 *
 *				_PROTECTED_WRITE(CPUINT_CTRLA,CPUINT_IVSEL_bm);
 *
 *		Setting IVSEL works.  Also, MAPPED_PROGMEM_START must be added to the addresses that are
 *		written to FLASH (no idea why).
 *	Channel data transferred via the "R" command is in reverse index order.= - fixed at the SRAM
 *		array assignment.  Unit-tested CLI xfer and SPI xfer to confirm reg order.
 *	Added debug hex dump to CLI commands: 'z' to dump either the temp channel ('z') or the
 *		FLASH channel array ('z f').
 *	Added channels to bring total to 8 (0 - 7).
 *	Closed "P" command hook to allow command to actually trigger a FLASH write from the temp
 *		channel.
 *	Added hook for "P" command to program temp channel to FLASH.
 *	Added code to capture TICSpro export lines and store them to a RAM buffer.
 *		Code ignores registers above 79 and registers must be sent in contiguous, decreasing
 *		order.  Errors if last reg# is not in-order or if line data extract doesn't find
 *		valid characters.  ASCII transfer with at least 1ms of line delay works provides
 *		error-free xfer.  Register index 79 arms transfer.  After that, all regs must be
 *		in descending order until reg# 0 is reached.  Sets XFR_DONE in cherror to signal
 *		a valid channel is waiting for the "P" command.
 *	Enabled serial.c to capture tabs since these are contained in the TICSpro export file as
 *		whitespace characters.
 *	Removed sscanf and added get_dec() and get_byte() plus support Fns.
 *	Attached caltemp and offtemp to temperature calculation.
 *	Added CAL and OFFset commands to read/write cal and offset data from/to EEPROM. These
 *		Will serve as the temperature calculation cal values allowing run-time var data
 *		that is not lost when the OFP is reloaded.  Imagine that!
 *		Moved these variables to USER EEPROM to prevent corruption when chip erase is performed.
 *		Required new EEPROM rd/wr fns in NVMCTRL_BASIC.C to allow access the USER area.
 *	modified code that fetches channel data to use flash_read function
 *	Coded to force pll_ary into FLASH at 0x7B00 (recipie is in channels.c). 
 *	Added DBUG build flag to allow debugging on the nano before testing on the target HW
 *
 * V0.2 Revnotes	10/16/24
 *	Cal'd temp sensor TLO value to match cold-on readings (external)
 *	channel register storage now only captures low 16b of each reg to save RAM/FLASH space.
 *		reg# is added at run-time by the send-data loop
 *	4-channels now supported
 *	re-vamped UART commands and added help ? cmd
 *  System now reports all FSEL input changes, but masks the active channel with FSEL_M.
 *		This mostly is in support of the ATP.
 *
 * V0.1 Revnotes	02/01/24 (circa)
 *	Initial release (debug) 1CH test loop
 *
 * Uses USART, ADC, SPI, and Timer0A, and Timer0B
 *
 * ADC measures temperature (using a diode-connected PNP device)
 * Timer0A is input capture-freq meas to determine if Fan speed is correct
 * Timer0B is for application timers and 32b ETI
 * Timer1B is for fan-speed capture (frequency measure, 28 - 150 Hz)
 * SPI sends data to LMX part.
 * USART is for debug serial messages and configuration management
 * GPIO:	nPTT input controls output (on/off)
 *			GPIO drives freq channel selection
 *
 * System uses state machine logic to manage the PLL channel selection/update process:
 *		= PLL init process:
 *			1) Apply power to device.
 *			2) Program RESET = 1 to reset registers.
 *			3) Program RESET = 0 to remove reset.
 *			4) Program registers as shown in the register map in REVERSE order from highest to lowest.
 *			5) Wait 10 ms.
 *			6) Program register R0 one additional time with FCAL_EN = 1 to ensure that the VCO calibration
 *				runs from a stable state.
 *
 *		= PLL freq-change process:
 *			1) Change the N-divider value.
 *			2) Program the PLL numerator and denominator.
 *			3) Program FCAL_EN (R0[3]) = 1.
 *
 *		= The USART sends status messages at the state changes which include a display of the ETI.  The ETI
 *			is a continuous, 32b register which is used to approximately place events relative to the IPL
 *			time (ETI = 0).  Event messages such as PTT transitions and periodic temperature reporting
 *			are also sent via the USART interface.  Serial commands to monitor or control system functions
 *			are also available via the USART interface.  See process_UART() for details.
 *
 *		= GPIO transitions are used to switch freq channel
 *
 *		+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 *
 *
 */

#include "mcu.h"		// defines MCU specifics, like SYSCLK rate (which is different for the automotive MCUs)
#include <stdio.h>
#include <stdlib.h>
#include <atmel_start.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <driver_init.h>
#include <clock_config.h>
#include "main.h"
#include "serial.h"
#include "channels.h"
#include "nvmctrl_basic.h"

#define BB_SPI								// use bit-bang SPI
#define DBUG								// debug build flag (for testing on nano)

// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// conditional compile flags - none
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

#define SBAUD		9600L //115200L					// remote control baud rate

// process_xxx() command defines
#define IPL_CMD		0xff					// Initial Program Load (reset system variables)
#define NORM_CMD	0x00					// normal process

/////////////////////////////////////
// file local fn declares
uint8_t process_UART(uint8_t cmd);
void exec_cmd(char* sptr);
void init_ports(void);
void put_eti(void);
void put_vers(void);
void put_eti_msg(char* sp);
void init_spi(void);								// SPI, init GPIO, etc...
void send_spi24(uint32_t plldata);
void delay_halfbit(void);							// for BBSPI, this fnd is just used to set reg-reg xfr delay
void pll_ipl(uint8_t chan);
uint32_t get_cal(uint8_t index);								// temperature cal/offset Fns
uint8_t put_cal(uint32_t dcal, uint8_t index);
uint16_t get_off(uint8_t index);
uint8_t put_off(uint16_t doff, uint8_t index);
char* get_byte(char* hptr, uint8_t* hexdest);
uint8_t asc_hex(char hchr);
void get_chreg(char* cptr);						// temp channel download Fn
uint8_t get_dec(char* cptr);
char* findx(char* cptr);

/////////////////////////////////////
// file local variables
#define TMPMAX	8
static	uint16_t	temp0[TMPMAX];					// current T0 temperature array (raw adc)
static	uint16_t	temp1[TMPMAX];					// current T1 temperature array (raw adc)
static	uint8_t		tmptr;							// current temp reg
static	bool		alert;							// LED alert status
static	bool		ipl;							// ipl flag
static	bool		ipll;							// pll ipl flag
static	uint8_t		ptt_last;						// ptt holding reg
//static	uint16_t	fan_speed;					// fan speed holding reg

static	uint32_t	caltemp0;
static	uint32_t	caltemp1;

#define cal32	0									// cal32 location into user eeprom

static	uint16_t	offtemp0;
static	uint16_t	offtemp1;

#define off16	(2*sizeof(uint32_t))				// offset location in user eeprom

static		uint16_t			chbuf[80];			// channel buffer regs
static		uint8_t				chreglast;			// last reg index (for error checking)
static		uint8_t				cherror;			// load file error register
static		char				buf[30];			// sprintf temp buff

//FUSE.APPEND qw = 0x76;	//, FUSE_BOOTEND
//,--section-start=.qfu=0x1287
//uint8_t		qfuse[2] __attribute__ ((section (".qfu"))) = { 0x76, 0x76 };;
//__attribute__(((section (".fuse")))

/*NVM_FUSES_t	__qfuse __attribute__((section (".FUSE")))  =
{
    .WDTCFG = FUSE0_DEFAULT,  // Watchdog Configuration 
    .BODCFG = FUSE1_DEFAULT,  //BOD Configuration 
    .OSCCFG = FUSE2_DEFAULT,  // Oscillator Configuration 
    .reserved_1[0] = 0xff,
    .TCD0CFG = FUSE4_DEFAULT,  // TCD0 Configuration 
    .SYSCFG0 = FUSE5_DEFAULT,  // System Configuration 0 
    .SYSCFG1 = FUSE6_DEFAULT,  // System Configuration 1 
    .APPEND = FUSE7_DEFAULT,  // Application Code Section End 
    .BOOTEND = FUSE8_DEFAULT,  // Boot Section End 
};*/

/////////////////////////////////////
// fn macros
//


////////////////////////////////////////////////////////////////////////////                                             
//			        ==     ==     =     =======  =     =        
//			        = =   = =    = =       =     ==    =        
//			        =  = =  =   =   =      =     = =   =        
//			        =   =   =  =     =     =     =  =  =        
//			        =       =  =======     =     =   = =        
//			        =       =  =     =     =     =    ==        
//			        =       =  =     =  =======  =     =        
////////////////////////////////////////////////////////////////////////////
// main()
int main(void){
	uint16_t			alert_counter;		// 
	uint16_t			jj;					// temp, er, temp
	uint16_t			adc_last;			// last adc reading
	uint8_t				i;					// temp 8
	uint8_t				j;					// temp 8
	uint8_t				fsel_edge;			// fsel edge holding reg
	static	uint16_t*	ctptr;				// current temp ptr

	_PROTECTED_WRITE(CPUINT_CTRLA,CPUINT_IVSEL_bm);
	atmel_start_init();										// init MCU
	init_ports();
	// countermand init...
/*	MUXO_set_dir(PORT_DIR_OUT);

	MUXO_set_pull_mode(
	    // <y> Pull configuration
	    // <id> pad_pull_config
	    PORT_PULL_OFF // Off
	    // <PORT_PULL_UP"> Pull-up
	    // PORT_PULL_UP
		);
		MUXO_set_level(1);*/

	timer_ipl();
	init_spi();
	adc_last = 0;
	tmptr = 0;
	ctptr = temp0;
	cherror = 0xff;											// init xfer error to invalid
	ipl = 1;												// set ipl flags
	ipll = 1;
	sei();													//enabling global interrupt
	// process initialization calls
	eti_read(ETI_IPL);										// IPL init of eti timer
	process_UART(IPL_CMD);									// init processes
	caltemp0 = get_cal(0);									// recall calibration temp vars
	caltemp1 = get_cal(1);
	offtemp0 = get_off(0);
	offtemp1 = get_off(1);
	put_eti();
	fsel_edge = 0xff;										// force update of ch/ptt
	alert = LED_NORM;
//	ALRT_set_level(alert);
	alert_counter = 20;
	chk_tmr4(alert_counter);
	ptt_last = 0xf0;
	CE_set_level(1);
//	pll_ipl();
	putss("<pll start>\n");

	//
	/* address change-capture application */
    while (1) // main loop (forever)
    {
		// alert LED/ETI msg. Alert LED flashes 5% on for normal operation, 95% on for ALERT indication
		if(!chk_tmr4(0)){									// I'm alive/Alert flash on alert LED
			// process alert
			if(alert_counter == 380){
				alert_counter = 20;
//				ALRT_set_level(!alert);						// the state of alert determines the LED duty cycle
//				MUXO_set_level(1);
				if(get_flag5()){							// send ETI msg @ 5 min intervals
					put_eti_msg(buf);
				}
			}else{
				alert_counter = 380;
//				ALRT_set_level(alert);
//				MUXO_set_level(0);
			}
			chk_tmr4(alert_counter);
		}
		i = nPTT_get_level();								// process PTT input & msgs
		if(i != ptt_last){
			if(i){
				if(ipll){
					fsel_edge = 0xff;						// force PLL update
					ipll = 0;								// clear ipl flag
				}
				CE_set_level(1);
				putss("Tone ON  ");
			}else{
				CE_set_level(0);
				putss("Tone OFF ");				
			}
			put_eti();
			ptt_last = i;
			wait_T(MS15);
		}
		i = PORTC_get_port_level() & (FSEL_MSK);
		if((i != fsel_edge) && (!ipll)){
			fsel_edge = i;
			j = ~fsel_edge & FSEL_MSK;
			pll_ipl(j & FSEL_M);							// nPTT = GND = enable PLL (plus 15ms debounce delay)
			sprintf(buf, "CH set: %d", j);
			putss(buf);
			sprintf(buf, "  PLL set: %d\n", j&FSEL_M);
			putss(buf);
		}
		// run each process function...
		process_UART(NORM_CMD);								// process UART commands
		// process temp
		

		if(ADC_0_got()){
			jj = ADC_0_get();										// acquire temp sensor & convert to ENG units (degrees K)
			if(jj != adc_last){
				if(jj == 0x3ff){
#ifndef DBUG
					putss("TEMP error; ");							// send log msg
					put_eti();
					ctptr[tmptr] = 9999;
					if(++tmptr >= TMPMAX) tmptr = 0;
					alert = 1;										// set alert
#endif
				}else{
					ctptr[tmptr] = jj;
					if(ipl){
						temp1[0] = IPL_TEMPERATURE;
						for(i=1; i<TMPMAX; i++){
							temp0[i] = temp0[0];
							temp1[i] = temp1[0];
						}
						ipl = 0;
					}
					if(++tmptr >= TMPMAX){
						tmptr = 0;
						if(ctptr == temp0){
							ADC0.MUXPOS = ADC_MUXPOS_AIN5_gc; /* ADC input pin 1 */
							ctptr = temp1;
						}else{
							ADC0.MUXPOS = ADC_MUXPOS_AIN4_gc; /* ADC input pin 0 */
							ctptr = temp0;
						}
					}
				}
				adc_last = jj;
			}
		}

    } // end main while() loop
} // end main()
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////
// process_UART() handles the UART commands
//	serial I/O drivers are in serial.c/serial.h
//
uint8_t process_UART(uint8_t cmd){
		uint8_t	i;				// temps
		uint8_t	j;
		uint8_t	k;
		uint8_t	m;
		char	cmd_buff[30];
//		char	obuf[16];
		char*	cptr;
		volatile char	c;
		uint16_t* aa;
		uint16_t jj;
//		uint16_t kk;
		uint32_t mm;

	if(cmd == IPL_CMD){
		init_uart(SBAUD, ENABLE_RXD|ENABLE_TXD);			// enable RXD & TXD
		putss("\n============\n");
		put_vers();
		putss("Artemis Start...\n");
	}else{
		// process uart input:
		if(gotcr()){
			cmd_buff[0] = '\0';						// pre-clear cmd buffer
			getss(cmd_buff);						// get cmd line
			c = cmd_buff[0];
			switch(c){
				case 'V':
					put_vers();						// display system version
				default:							// empty line displays eti msg
					put_eti_msg(cmd_buff);
					break;

/*				case 'p':							// "P" pll IPL config
				case 'P':
					pll_ipl(0);
					putss("<pll init>\n");
					break;*/

				case '0':							// CH0
				case '1':							// CH1
				case '2':							// CH2
				case '3':							// CH3
				case '4':							// CH4
				case '5':							// CH5
				case '6':							// CH6
				case '7':							// CH7
					pll_ipl(c-'0');
					putss("Set CH: ");
					buf[0] = c;
					buf[1] = '\n';
					buf[2] = '\0';
					putss(buf);
					break;
					
				case 'n':							// "N" init pll GPIO
				case 'N':
					CE_set_level(1);
					putss("<pll ON>\n");
				break;
					
				case 'f':							// "F" pll chip off
				case 'F':
					CE_set_level(0);
					putss("<pll OFF>\n");
					break;

				case 'R':							// TICSpro config line input cmd
					get_chreg(&cmd_buff[1]);		// send CLIN (past "r" chr) to cmd for processing
					break;

				case 'P':							// PGM temp channel to FLASH
					if(cherror == XFR_DONE){
						i = get_dec(&cmd_buff[1]);
						if(i < NUM_CH){
							volatile uint8_t temp_page[PROGMEM_PAGE_SIZE];		// temp page buffer
							// transfer temp channel to FLASH
//             nvmctrl_status_t FLASH_0_write_flash_block(flash_adr_t flash_adr, uint8_t *data, size_t size, uint8_t *ram_buffer)
			   				j = FLASH_0_write_flash_block((flash_adr_t)(chan_ptr(i)), (uint8_t *)chbuf, (size_t)(NUM_REG * sizeof(uint16_t)), temp_page);
							sprintf(buf, "PGM done: 0x%02x\n", j);
							putss(buf);
						}else{
							putss("CH# error.\n");
						}
					}else{
						putss("XFER error.\n");
					}
					break;

				case 'E':							// Erase
					j = FLASH_0_erase_flash_page((flash_adr_t)(chan_ptr(0)));
					sprintf(buf, "Erase done: 0x%02x\n", j);
					putss(buf);
					sprintf(buf, "nvmADDR: 0x%02x%02x\n", NVMCTRL_ADDRH, NVMCTRL_ADDRL);
					putss(buf);
					//
					break;

				case 't':
					putss("Set Temp Chan\n");
					pll_ipl(0xff);
					break;

				case '?':							// help
					putss("\nArtemis Help (cmds are case sensitive):\n");
					putss("0-7: force-set PLL CH\n");
					putss("n: tone on\n");
					putss("f: tone off\n");
					putss("cn: set hex U32 EE cal 'HGFEDCBA'\n");
					putss("Cn: Read EE cal\n");
					putss("on: set hex EE offs 'DCBA'\n");
					putss("On: Read U16 EE offs\n");
					putss("  n = sens#, 1/0\n");
					putss("R: Download data to temp channel reg\n");
					putss("   Rn..n<tab>0xiirrrr\n");
					putss("\tn..n = reg index (dec)\n");
					putss("\t<tab> = ASCII 0x09\n");
					putss("\t0xii = hex qualifier & hex index\n");
					putss("\trrrr = hex reg data\n");
					putss("Pc: PGM temp channel to ch# 'c'\n");
					putss("t: send download data to PLL\n");
					putss("<ENTER>: display ETI(sec)/temp(K) stats\n");
					putss("    T0=regulator, T1=PLL\n");
					putss("V: SW Version\n\n");
					putss("a/A: read raw ADC, ch0/1\n");
					putss("z: debug sram hex dump\n");
					putss("z f: debug FLASH hex dump\n");
					break;

				case 'c':							// set cal
					//cn hhhhhhhh
					//012345678901
					m = cmd_buff[1] & 0x01;			// get index
					sprintf(buf, "\nSet Cal Temp Sense%d:\n", m);
					putss(buf);
					mm = 0;
					j = 0;
					for(cptr=&cmd_buff[3], i=0; i<4; i++){
						if(get_byte(cptr, &k) == cptr) j = 1;
						cptr += 2;
						mm <<= 8;
						mm |= (uint32_t)k;
					}
					if(!j){
						if(m){
							caltemp1 = mm;
							put_cal(caltemp1, 1);
						}else{
							caltemp0 = mm;
							put_cal(caltemp0, 0);
						}
						putss("Done.\n");
					}else{
						putss("Error!\n");						
					}
				case 'C':							// read cal
					m = cmd_buff[1] & 0x01;			// get index
					putss("\nRead Cal Temp Sense");
					mm = get_cal(m);
					sprintf(buf, "%d: 0x%04x", m, (uint16_t)(mm>>16));
					putss(buf);
					sprintf(buf, "%04x\n", (uint16_t)(mm));
					putss(buf);
					break;
					
				case 'o':							// set offset
					m = cmd_buff[1] & 0x01;			// get index
					sprintf(buf, "\nSet OFFS Temp Sense%d:\n", m);
					putss(buf);
					jj = 0;
					j = 0;
					for(cptr=&cmd_buff[3], i=0; i<2; i++){
						if(get_byte(cptr, &k) == cptr) j = 1;
						cptr += 2;
						jj <<= 8;
						jj |= (uint16_t)k;
					}
					if(!j){
						if(m){
							offtemp1 = jj;
							put_off(offtemp1, 1);
						}else{
							offtemp0 = jj;
							put_off(offtemp0, 0);
						}
						putss("Done.");
					}else{
						putss("Error!\n");						
					}
				case 'O':							// read offs
					m = cmd_buff[1] & 0x01;			// get index
					putss("\nRead OFFS Temp Sense");
					if(m){
						jj = offtemp1;
					}else{
						jj = offtemp0;
					}
					sprintf(buf, "%d: 0x%04x\n", m, jj);
					putss(buf);
					break;
					
				case 'a':
					for(i=0, mm=0; i<TMPMAX; i++){
						mm += (uint32_t)temp0[i];
					}
					jj = (uint16_t)(mm/TMPMAX);
					sprintf(buf, "ADC0: 0x%04x\n", jj);
					putss(buf);
					break;
					
					case 'A':
					for(i=0, mm=0; i<TMPMAX; i++){
						mm += (uint32_t)temp1[i];
					}
					jj = (uint16_t)(mm/TMPMAX);
					sprintf(buf, "ADC1: 0x%04x\n", jj);
					putss(buf);
					break;
					
				case 'z':							// debug
					if(cmd_buff[2] == 'f'){											// read 1st page of FLASH
						putss("\nread FLASH:\n");
						sprintf(buf, "AEND: 0x%04x BEND: 0x%04x\n", FUSE_APPEND, FUSE_BOOTEND);
						putss(buf);
						aa=(uint16_t*)(chan_ptr(0)-8);
						for(j=0; j<81; j++){
							sprintf(buf, "\n%04x: ", (uint16_t)aa);
							putss(buf);
							for(i=0; i<8; i++, aa+=1){
								jj = FLASH_0_read_flash_word((flash_adr_t)aa);
								sprintf(buf, "%04x ", jj);
								putss(buf);
							}
						}
					}else{															// read channel temp buffer (SRAM)
						putss("\nread SRAM ch buffer:");
						aa=chbuf;
						for(j=0; j<10; j++){
							sprintf(buf, "\n%04x: ", (uint16_t)aa);
							putss(buf);
							for(i=0; i<8; i++, aa+=1){
								jj = *aa;
								sprintf(buf, "%04x ", jj);
								putss(buf);
							}
						}						
					}
					putss("\n");
					break;



/*					putss("\nread flash:\n");
					aa=(uint16_t*)chan_ptr(0);
					sprintf(obuf, "%04x: ", (uint16_t)aa);
					putss(obuf);
					for(i=0; i<8; i++, aa+=1){
						jj = FLASH_0_read_flash_word((flash_adr_t)aa);

//						jj = (uint16_t)FLASH_0_read_flash_byte(aa);			// add register addr <<< put FLASH READ WORD here !!!
//						jj |= (uint16_t)FLASH_0_read_flash_byte(aa+1) << 8;
						sprintf(obuf, "%04x ", jj);
						putss(obuf);
					}
					putss("\n");
					break;*/

/*				case 's':							// "S" spi debug
				case 'S':
					send_spi24(0x00a5aa55);
//					sprintf(cmd_buff, "<set %d%%>\n", j);
//					putss(cmd_buff);
					putss("<spi dbg>\n");
					break;*/
			}  // end switch
		} // end if-gotcr
	} // end if-cmd
	return 0;
}


/////////////////////////////////////
// init_ports() initializes GPIO
//
void init_ports(void){

	// init GPIO
	PORTC.OUT = 0;
	PORTC.DIR = 0;
	PORTC.PIN0CTRL = PORT_PULLUPEN_bm;

	return;
}

/////////////////////////////////////
// put_eti() displays eti (in sec) on USART port
//
void put_eti(void){
//	char	buf[32];

	putss("ETI: ");
	sprintf(buf,"%ld\n", eti_read(0));
	putss(buf);
	return;
}

/////////////////////////////////////
// put_eti() displays eti (in sec) on USART port
//
void put_eti_msg(char* sp){
	uint32_t	jj = 0;
	uint32_t	kk = 0;
	uint32_t	mm = 0;
	uint8_t		i;

	for(i=0; i<TMPMAX; i++){
		jj += (uint32_t)temp0[i];
		kk += (uint32_t)temp1[i];
	}
	jj /= TMPMAX;
	kk /= TMPMAX;
	mm = caltemp0 / (int32_t)jj;		// KADC
	mm += (uint32_t)offtemp0;
	// !!! put adc->degK calcs here
	sprintf(sp, "T0:%d.%d K; ", (int)(mm/10), (int)(mm%10));
	putss(sp);
	mm = caltemp1 / (int32_t)jj;		// KADC
	mm += (uint32_t)offtemp1;
	sprintf(sp, "T1:%d.%d K; ", (int)(mm/10), (int)(mm%10));
	putss(sp);
	put_eti();
	return;
}

// *********************************************
//  ************* SPI SUBROUTINES *************
// *********************************************

/////////////////////////////////////
// init_spi() initializes SPI port, master
// PA1 = MOSI
// PA3 = SCK
//
void init_spi(void){								// for HWSPI, initialize MCU pins

	MOSI_set_level(0);								// MOSI
	SCK_set_level(0);								// SCK
	nCS_set_level(1);								// CS
	CE_set_level(0);								// chip enable
	return;	
}

/////////////////////////////////////
// pll_ipl() initializes the LMX2594 to the given channel#
//	chan == 0xff specifies the SRAM temp channel
//
void pll_ipl(uint8_t chan){
	volatile uint32_t	i;
	volatile uint16_t*	pptr;
	volatile uint32_t	ss;		// spi data

	send_spi24(R0_ADDR | R0_RESET);					// send reset
	send_spi24(R0_INIT);
	if(chan == 0xff){
		pptr = chbuf;								// point to temp chan
	}else{
		pptr = (uint16_t*)chan_ptr(chan);			// get pointer to FLASH channel data
	}
	if(pptr == NULL){
			putss("CHAN ERR\n");					// pointer error
	}else{
		// send chan array with reg addr added (bits [23:16])
		for(i=REGNUM_START; i <= REGNUM_START; i-=0x10000L){
			if(chan == 0xff){
				ss = i | (uint32_t)(*pptr++);		// add register addr >> read from SRAM
			}else{
				ss = i | (uint32_t)(FLASH_0_read_flash_word((flash_adr_t)pptr++));			// add register addr >> read from FLASH
			}
			send_spi24(ss);
			// debug
//			sprintf(buf,"0x%02x%04x\n", (uint16_t)(ss>>16),(uint16_t)(ss&0xffff));
//			putss(buf);
		}
	}
	// pause (for debounce)
	wait_T(MS15);
	// enable VCO cal
	send_spi24(R0_INIT | R0_FCAL_EN);
//	send_spi24(R0_INIT);
	return;
}


//-----------------------------------------------------------------------------
// send_spi32
//-----------------------------------------------------------------------------
//
// sends 24 bit word to target via bit-bang SPI
//
void send_spi24(uint32_t plldata){
#ifdef BB_SPI
	uint32_t	mask;

	nCS_set_level(0);								// CS = low to clock in data
	for(mask = 0x00800000L; mask;){	// start shifting 24 bits starting at MSb
		if(mask & plldata) PORTA.OUT |= MOSI;		// set MOSI
		else PORTA.OUT &= ~MOSI;					// clear MOSI
		mask >>= 1;
//		delay_halfbit();							// delay half clock

//		SCK_set_level(1);
		PORTA.OUT |= SCK;							// clock = high
//		delay_halfbit();							// delay remaining half
//		SCK_set_level(0);
		PORTA.OUT &= ~SCK;							// clock low
	}
	delay_halfbit();								// delay for LE
	nCS_set_level(1);								// CS = hi to latch data
	delay_halfbit();								// pad intra-word xfers by a half bit
	return;	

#else
	uint8_t	i;	// loop temps
	uint8_t	d;
	union Data32 {	// temp union to parse out 32b word to 8b pieces
	   uint32_t l;
	   uint8_t b[4];
	} pllu;  

	pllu.l = plldata;
	nCS_set_level(0);								// CS = low to clock in data
	delay_halfbit();								// pad intra-word xfers by a half bit
	for(i=0; i < 4; i++){							// shifting 32 bits 8 bits at a time
		d = (uint8_t)(pllu.b[i]);
//		while(SPI0CFG & 0x80);						// wait for buffer to clear
//		SPI0DAT = d;
	}
//	while(SPI0CFG & 0x80);							// wait for buffer to clear
	delay_halfbit();								// pad intra-word xfers by a half bit
	nCS_set_level(1);								// CS = hi to latch data
	delay_halfbit();								// delay for RC pullup on revC CS line
	return;
#endif
}

//-----------------------------------------------------------------------------
// delay_halfbit
//-----------------------------------------------------------------------------
//
// sets delay for spi SCK and for CS setup/hold
//
	// BitBang version uses for-loop to establish ~~200 us delay
void delay_halfbit(void){
	volatile uint8_t	i;
	
	for(i = 0; i < 1;){							// cheezy for-next-loop to set delay for bit-bang-spi
													// 500 loops is approx 200us
		i += 1;
	}
	return;	
}
/*
#ifdef BB_SPI
	// BitBangSPI version uses HW timer0 to establish the bit-delay (200us, nominal)
	// T0 has about 0.5us of delay per timer tic when configured for clock source = SYSCLK/12
	// define 200us timer delay @24.5MHz/12 timer clock = (65536 - (400*0.5us))
#define	T0_VALUE	65136
#else
	// HWSPI version uses HW timer0 to establish quick delay (8us, nominal)
	// T0 has about 0.5us of delay per timer tic when configured for clock source = SYSCLK/12
	// define 8us timer delay @24.5MHz/12 timer clock = (65536 - (16*0.5us))
#define	T0_VALUE	0xFFF0
#endif

void delay_halfbit(void){							// for HWSPI, this fnd is just used to set reg-reg xfr delay

	TH0 = (T0_VALUE >> 8);							// prep timer registers for delay
	TL0 = (T0_VALUE & 0xFF);
	TF0 = 0;
	TR0 = 1;										// start timer
	while(TF0 == 0);								// loop
	TR0 = 0;										// stop timer
	return;	
}
*/

/////////////////////////////////////
// get_cal() fetches temperature cal value from USER EEPROM.
//	The U32 value is stored as 4 U8 values in array index order.

uint32_t get_cal(uint8_t index){
	uint8_t		i;
	uint32_t	jj;

	for(i=0, jj=0; i<4; i++){
		jj <<= 8;
		jj |= (uint32_t)FLASH_0_read_user_byte((eeprom_adr_t)(cal32+i)*(index+1));
	}
	return jj;
}

/////////////////////////////////////
// put_cal() stores temperature cal value to USER EEPROM.
//	The U32 value is stored as 4 U8 values in array index order.

uint8_t put_cal(uint32_t dcal, uint8_t index){
	uint8_t			i;
	nvmctrl_status_t e;
	uint32_t		jj = dcal;

	i=3;
	do{
		while(FLASH_0_is_eeprom_ready());			// wait for EEPROM ready
		e = FLASH_0_write_user_byte((eeprom_adr_t)(cal32+i)*(index+1), (uint8_t)jj);
		jj >>= 8;
		i -= 1;
	}while((i != 0xff) && (e != NVM_ERROR));
	while(FLASH_0_is_eeprom_ready());				// wait for EEPROM ready
	return e;
}

/////////////////////////////////////
// get_off() fetches temperature offset value from USER EEPROM.
//	The U16 value is stored as 2 U8 values in array index order.

uint16_t get_off(uint8_t index){
	uint8_t		i;
	uint16_t	jj;

	for(i=0, jj=0; i<2; i++){
		jj <<= 8;
		jj |= (uint16_t)FLASH_0_read_user_byte((eeprom_adr_t)(off16+i)*(index+1));
	}
	return jj;
}

/////////////////////////////////////
// put_off() stores temperature cal value to USER EEPROM.
//	The U32 value is stored as 4 U8 values in array index order.

uint8_t put_off(uint16_t doff, uint8_t index){
	uint8_t			i;
	nvmctrl_status_t e;
	uint16_t		jj = doff;

	i=1;
	do{
		while(FLASH_0_is_eeprom_ready());			// wait for EEPROM ready
		e = FLASH_0_write_user_byte((eeprom_adr_t)(off16+i)*(index+1), (uint8_t)jj);
		jj >>= 8;
		i -= 1;
	}while((i != 0xff) && (e != NVM_ERROR));
	while(FLASH_0_is_eeprom_ready());				// wait for EEPROM ready
	return e;
}

/////////////////////////////////////
// get_ byte() takes two ASCII hex values at ptr and ptr+1
//	and passes back the hex value via pointer
//	returns ptr+2 unless error, then the null ptr is returned
//	Both characters must be valid hex or returns error

char* get_byte(char* hptr, uint8_t* hexdest){
	uint8_t			i;
	uint8_t			j;

	i=asc_hex(*hptr);
	j=asc_hex(*(hptr+1));
	if((i>0xf) || (j>0xf)) return hptr;
	*hexdest = (i<<4) | j;
	return hptr+2;
}

/////////////////////////////////////
// asc_hex() takes ASCII hex chr and returns hex value (0xff is error)
//	character must be valid hex or returns error

uint8_t asc_hex(char hchr){
	uint8_t			i=(uint8_t)hchr;

	if((i>='a') && (i<='z')) i -= 'a'-'A';			// upcase
	if((i<'0') || (i>'F')){
		return 0xff;								// error
	}else{
		i -= '0';									// convert to hex
		if(i>9){
			if(i<('A'-'0')){
				return 0xff;						// error
			}else{
				i -= ('A'-'9'-1);				
			}
		}
	}
	return i;										// if i>0xf, it is an error
}

/////////////////////////////////////
// get_dec() takes ASCII chrs from ptr stream and converts to decimal until wspc

uint8_t get_dec(char* cptr){
	uint8_t	i = 0xff;
	uint8_t	isdec=1;
	char	c;

	do{
		c = *cptr++;
		if((c>='0') && (c<='9')){
			if(i == 0xff) i = 0;
			i *= 10;
			i += (uint8_t)(c - '0');
		}else{
			isdec = 0;
		}
	}while(isdec);
	return i;
}

/////////////////////////////////////
// findx() looks for "x" or <EOL>
//	Returns ptr to "x"+1 or null if <EOL>

char* findx(char* cptr){
	char	c;

	do{
		c = *cptr++;
	}while((c != 'x') && (c != '\n') && (c != '\0'));
	if(c <= ESC) return NULL;
	return cptr;
}

/////////////////////////////////////
// get_chreg() processes CLIN string for "R" register setting command
// cptr points to byte immediately following the "R"  start of line.
// TICSpro file export line format:
//		Rn..n<tab>0xiirrrr
//
//	n..n = reg index (1 to 3 digits, dec)\n"), valid digits are '0' thru '9'
//	<tab> = ASCII 0x09, any whitespace is valid
//	0x = hex qualifier
//	ii = hex index must == dec index, valid hex is '0'-'9', 'a'-'f', not case sensitive
//	rrrr = hex reg data
//
// Sending the raw TISCpro file via ASCII transfer with 1ms of line delay is sufficient
//	to achieve valid transfer.  This algorithm ignores registers above index 79.  Index
//	values of 79 to 0 must be sent in descending order or an index error is issued.
//	If the line does not present valid data in the fields described above, a format error
//	is issued.

void get_chreg(char* cptr){
	uint8_t		i = 0xff;
	uint8_t		j;
	char*		sptr;
	char*		tptr;
	uint16_t	ii;
	
	j = get_dec(cptr);
	if(j == START_REG){
		cherror = 0;
		chreglast = START_REG + 1;
	}
	if((j <= REG79) && !(cherror & XFR_DONE)){
		// check for index error
		if(j != chreglast - 1) cherror |= INDX_ERROR;
		// find "x" in hex specifier prefix
		sptr = findx(cptr);
		if(sptr != NULL){
			// get hex index & make sure it matches the decimal value
			tptr = get_byte(sptr, &i);
			if(tptr == sptr) cherror |= FMT_ERROR;
			else sptr = tptr;
			if(i != j) cherror |= INDX_ERROR;
			// get register word, msB first
			tptr = get_byte(sptr, &i);
			if(tptr == sptr) cherror |= FMT_ERROR;
			else sptr = tptr;
			ii = (uint16_t)i << 8;
			// get lsB
			tptr = get_byte(sptr, &i);
			if(tptr == sptr) cherror |= FMT_ERROR;
			ii |= (uint16_t)i;
			// store reg word to temp channel (SRAM)
			chbuf[START_REG-j] = ii;
		}else{
			// no "x" found, set format error
			cherror |= FMT_ERROR;
		}
		// test for end of reg list (when index == 0)
		if(j == 0){
			// display error status or done
			if(cherror){
				sprintf(buf,"Error: 0x%02x\n", cherror);
				putss(buf);
			}else{
				putss("CH Load complete.\n");
				cherror = XFR_DONE;
			}
			// return transfer complete
		}
		// update last index
		chreglast = j;
	}
	return;
}


/////////////////////////////////////
// put_vers() displays system version
//
void put_vers(void){

	putss("Artemis 2-15GHz PLL, V0.3, 4-chan\n");
	putss("'?<ent>' for help, 03/28/25, de KE0FF\n");
	return;
}

// eof
