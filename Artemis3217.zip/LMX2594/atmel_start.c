#define MN3217 1				// define MCU PN to set SYSCLK
#include <atmel_start.h>

/**
 * Initializes MCU, drivers and middleware in the project
 **/
void atmel_start_init(void)
{
	system_init();
}
