/********************************************************************
 ************ COPYRIGHT (c) 2025 by ke0ff, Taylor, TX   *************
 *
 *  File name: serial.h
 *
 *  Module:    Control
 *
 *  Summary:   This is the header file for serial I/O.
 *
 *******************************************************************/


/********************************************************************
 *  File scope declarations revision history:
 *    02-20-22 jmh:  creation date
 *
 *******************************************************************/

//------------------------------------------------------------------------------
// extern defines
//------------------------------------------------------------------------------

#define USART0_BAUD_RATE(BAUD_RATE) ((float)(F_CPU * 64 / (16 * (float)BAUD_RATE)) + 0.5)

#define SOH		0x01
#define ETX		0x03
#define	EOT		0x04
#define AKN		0x06
#define	EOL		13						// <CR> is EOL / end of msg
#define DLE		0x10
#define XON		0x11
#define XOFF	0x13
#define NAK		0x15
#define CAN		0x18
#define TAB		0x09
#define ESC		27
#define SW_ESC	0xa5					// sw restart escape code
#define	myEOF	26
#define ENABLE_RXD	0x01				// UART tx/rx enable masks
#define ENABLE_TXD	0x02

// Timer and retry limits
#define	XM_TO			(3*ONESEC)		// 3 seconds for xmodem timeout
#define ACKTRIES		10				// # tries to do start of packet before abort
										// this gives 30 sec to start an xmodem transfer in CRC before
										// SW reverts to checksum
#define	CIV_PREA		0xfe			// CIV message preamble
#define	CIV_HADDR		0xe0			// cntlr addr
#define	CIV_RADDR		0x70			// radio address
#define	CIV_EOM			0xfd			// CIV message end-of-msg
#define	CIV_OK			0xfb			// CIV message OK
#define	CIV_NG			0xfa			// CIV message no-good
#define	CIV_JAM			0xfc			// CIV jammer code
#define CIV_TIMEOUT 	100				// (ms) CIV send chr timeout limit
#define	CIV_RETRY_LIM	4				// retry limit
#define	CIV_JAMOUT		30				// (ms) CIV jammer code timeout
#define	CIV_MSGWAIT		50				// (ms) CIV message wait delay

//------------------------------------------------------------------------------
// public Function Prototypes
//------------------------------------------------------------------------------

void init_uart(uint32_t baudr, uint8_t enab);
char putch(char c);
char getch00(void);
void cleanline(void);
char gotch00(void);
char gotcr(void);
void putss (char* string);
char* puts_byte(char* s, uint8_t d);
char* getss (char* dest);
